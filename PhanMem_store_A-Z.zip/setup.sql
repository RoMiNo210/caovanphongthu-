-- PHAN MEM.STORE - SUPABASE SETUP
-- Chạy toàn bộ file này trong Supabase > SQL Editor > New query > Run.
-- Không xóa dữ liệu cũ vì đây là dự án mới.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  price numeric(12,0) not null default 0 check (price >= 0),
  image_url text not null default '',
  stock integer not null default 0 check (stock >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  product_id uuid not null references public.products(id) on delete restrict,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(12,0) not null check (unit_price >= 0),
  total numeric(12,0) not null check (total >= 0),
  status text not null default 'pending' check (status in ('pending','processing','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.deposits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  amount numeric(12,0) not null check (amount > 0),
  method text not null default 'Chuyển khoản',
  note text not null default '',
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  );
$$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name',''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.place_order(p_product_id uuid, p_quantity integer)
returns uuid language plpgsql security definer
set search_path = public
as $$
declare
  v_product public.products%rowtype;
  v_order_id uuid;
begin
  if auth.uid() is null then raise exception 'Vui lòng đăng nhập trước khi đặt hàng'; end if;
  if p_quantity is null or p_quantity < 1 or p_quantity > 100 then
    raise exception 'Số lượng không hợp lệ';
  end if;
  select * into v_product from public.products
  where id = p_product_id and active = true
  for update;
  if not found then raise exception 'Sản phẩm không tồn tại hoặc đã ngừng bán'; end if;
  if v_product.stock < p_quantity then raise exception 'Không đủ hàng trong kho'; end if;
  update public.products set stock = stock - p_quantity where id = p_product_id;
  insert into public.orders(user_id, product_id, product_name, quantity, unit_price, total)
  values (auth.uid(), v_product.id, v_product.name, p_quantity, v_product.price, v_product.price * p_quantity)
  returning id into v_order_id;
  return v_order_id;
end;
$$;

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.deposits enable row level security;

drop policy if exists "profile select own or admin" on public.profiles;
create policy "profile select own or admin" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_admin());

drop policy if exists "profile update own name" on public.profiles;
create policy "profile update own name" on public.profiles
for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and role = 'user');

drop policy if exists "products public read active" on public.products;
create policy "products public read active" on public.products
for select to anon, authenticated using (active = true or public.is_admin());

drop policy if exists "products admin insert" on public.products;
create policy "products admin insert" on public.products
for insert to authenticated with check (public.is_admin());

drop policy if exists "products admin update" on public.products;
create policy "products admin update" on public.products
for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "products admin delete" on public.products;
create policy "products admin delete" on public.products
for delete to authenticated using (public.is_admin());

drop policy if exists "orders select own or admin" on public.orders;
create policy "orders select own or admin" on public.orders
for select to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists "orders admin update" on public.orders;
create policy "orders admin update" on public.orders
for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "deposits select own or admin" on public.deposits;
create policy "deposits select own or admin" on public.deposits
for select to authenticated using (user_id = auth.uid() or public.is_admin());

drop policy if exists "deposits insert own" on public.deposits;
create policy "deposits insert own" on public.deposits
for insert to authenticated with check (user_id = auth.uid() and status = 'pending');

drop policy if exists "deposits admin update" on public.deposits;
create policy "deposits admin update" on public.deposits
for update to authenticated using (public.is_admin()) with check (public.is_admin());

grant usage on schema public to anon, authenticated;
grant select on public.products to anon, authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.products to authenticated;
grant select, update on public.orders to authenticated;
grant select, insert, update on public.deposits to authenticated;
grant execute on function public.is_admin() to anon, authenticated;
grant execute on function public.place_order(uuid, integer) to authenticated;

-- Thêm sản phẩm demo để kiểm tra. Có thể xóa/chỉnh sửa trong trang quản trị.
insert into public.products(name, description, price, image_url, stock, active)
select 'Windows 11 Pro - Demo', 'Sản phẩm mẫu để kiểm tra website. Hãy thay nội dung và giá trước khi bán thật.', 99000, '', 10, true
where not exists (select 1 from public.products);
